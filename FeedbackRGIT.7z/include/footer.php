<style media="screen">
.admin_nav{
  text-transform: uppercase;
  font-family: Montserrat-SemiBold;
}
</style>
<footer class="py-2 bg-dark">
    <div class="container-fluid">
      <p class="m-0 text-right text-white admin_nav" style="font-size:10">Developed by: Nitish Talekar, Sarvesh Wanode, Aayush Singh</p>
    </div>
</footer>
