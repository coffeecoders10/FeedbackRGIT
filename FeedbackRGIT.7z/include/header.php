<style media="screen">
  .admin_nav{
    text-transform: uppercase;
    font-family: Montserrat-SemiBold;
  }
</style>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand admin_nav" href="/FeedbackRGIT/admin">Admin</a>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link admin_nav" href="/FeedbackRGIT/admin/admin.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link admin_nav" href="/FeedbackRGIT/">Feedback</a>
      </li>
    </ul>
  </div>
</nav>